from django.apps import AppConfig


class AsendConfig(AppConfig):
    name = 'asend'
