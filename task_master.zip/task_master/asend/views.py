from django.shortcuts import render


from django.urls import reverse
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.models import User
from django.http import HttpResponse

from django.views.generic import DeleteView, UpdateView, ListView, DetailView, CreateView
from django import forms
from django.forms import widgets
from django.forms import ModelForm

# Create your views here.

from django.contrib.auth import get_user_model
from django.http import JsonResponse
from django.views.generic import View

from rest_framework.views import APIView
from rest_framework.response import Response

from django.db.models import Q

from .models import Entry, Category
from django.db.models import Max

# Create your views here.
class EntryListView(ListView):

	model = Entry
	template_name = 'asend/home.html'
	context_object_name = 'entries'
	ordering = ['value']
	def get_context_data(self, **kwargs):
		c = Category.objects.all()[:1].get()
		context = super(EntryListView, self).get_context_data(**kwargs)
		context['first'] = Entry.objects.all().filter(category=c).order_by('-value').first()
		return context

class CategoryDetailView(LoginRequiredMixin, DetailView):
	model = Category
	context_object_name = 'category'
	template_name = 'asend/category_detail.html'
	ordering = ['value']
	
	def get_context_data(self, **kwargs):
		c = Category.objects.all().get(pk=self.object.pk)
		context = super(CategoryDetailView, self).get_context_data(**kwargs)
		context['entries'] = Entry.objects.all().filter(category=c).order_by('-value')
		return context

class EntryDetailView(LoginRequiredMixin, DetailView):
	model = Entry
	context_object_name = 'object'
	template_name = 'asend/entry_detail.html'



class EntryCreateView(LoginRequiredMixin, CreateView):
	model = Entry
	fields = ['category','value','video','description']

	def form_valid(self, form):
		form.instance.creator = self.request.user
		return super().form_valid(form)

class CategoryCreateView(LoginRequiredMixin, CreateView):
	model = Category
	fields = ['name','description']

	def form_valid(self, form):
		form.instance.creator = self.request.user
		return super().form_valid(form)

	
