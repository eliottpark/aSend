from django.db import models
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.urls import reverse
import datetime
import calendar




# Create your models here.
class Entry(models.Model):
	value = models.IntegerField()
	creator = models.ForeignKey(User, max_length=100, on_delete=models.CASCADE, null=True, blank=True)
	category = models.ForeignKey('Category',max_length=100, on_delete=models.CASCADE)
	video =  models.CharField(max_length=100, null=True, blank=True)
	metric = models.CharField(max_length=100, null=True, blank=True)
	description = models.CharField(max_length=100, null=True, blank=True)
	
	def get_absolute_url(self):
		e = Entry.objects.all().get(pk=self.id)
		c = Category.objects.all().get(pk=e.category.id)
		e.metric = c.metric
		e.save()
		return reverse('home')
	def __str__(self):
		return str(self.name)



class Category(models.Model):
	name = models.CharField(max_length=100, null=True, blank=True)
	description = models.TextField(null=True, blank=True)
	creator = models.CharField(max_length=100)
	def get_absolute_url(self):
		return reverse('home')
	def __str__(self):
		return str(self.name)



